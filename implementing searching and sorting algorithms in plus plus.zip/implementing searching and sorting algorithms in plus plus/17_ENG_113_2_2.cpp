// 1st of all we have to save the txt files in the project folder
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <chrono>
#include <ctime>
#include <cstdlib>

//global variables to count steps of searching algorithms
int count1= 0; //for linear search
int count2 = 0;//for binary search
int count3 = 0;//for jump serach
int count4 = 0;//for interpolation search


using namespace std;

// function to print the array
void printArray(int arr[], int n)  //this is okay
{
	for (int i = 0; i < n; i++)
	{
		cout << arr[i];
		cout << endl;
	}}
void swap(int *xp, int *yp)// this is correct
{
	int temp = *xp;
	*xp = *yp;
	*yp = temp;
}


class MySearch
{
public:

	void Selection_Sort(int * arr, int n) //this is okay
	{
		int minindex;
		for (int i = 0; i < n - 1; i++)
		{
			minindex = i;
			for (int j = i + 1; j < n; j++)
			{
				if (arr[j] < arr[minindex])
				{
					minindex = j;
				}
				// Swap the found minimum element with the first element 
				swap(&arr[minindex], &arr[i]);
			}
		}
	}

    int  Linear_Search(int *arr, int left, int right , int x)//this is okay
	{
		
		for ( int i=left ; i < right; i++)
		{
			count1++; 
			
				if (arr[i] == x){
					return i; 
			}

			
		}
		return -1;
	}

	int Binary_Search(int arr[], int l, int r, int x) //this is okay
	{
		while (l <= r)
		{
			count2++;
			int mid = l + (r - l) / 2;

			if (arr[mid] == x)
				return mid;

			if (arr[mid] < x)
				l = mid + 1;
			else
				r = mid - 1;
		}

		return -1;
	}

	int Jump_Search(int arr[], int intsize, int x) // this is also correct
	{
		int step = sqrt(intsize);
		int previous = 0;

		while (arr[step] <= x && step < intsize)
		{
			count3++;
			previous = step;
			step += sqrt(intsize);
			if (previous >= intsize - 1)
				return -1;
		}

		for (int i = previous; i < step; i++)
		{
			count3++;
			if (arr[i] == x)
			{
				return i;
			}
		}

		return -1;
	}

	int  Interpolation_Sort(int arr[], int intsize, int x) //this is okay-
	{
		int low = 0, high = (intsize - 1);

		while (low <= high && x >= arr[low] && x <= arr[high])
		{
			count4++;
			if (low == high)
			{
				if (arr[low] == x)
					return low;
				return -1;
			}

			int pos = low + (high - low)*(x - arr[low]) / (arr[high] - arr[low]);
			if (arr[pos] == x)
			{
				return pos;
			}

			if (arr[pos] < x)
			{
				low = pos + 1;
			}
			else
			{
				high = pos - 1;
			}

		}

		return -1;

	}

};


int main()
{
	int a = 0;
	int SearchNum; // the number that we want to search
	int vriable = 0;


	// we cn use two string arrays to store data
	int *arr1 = new int[20000];
	


		
			//getting the text files and we can store this in array
			string lines;
			ifstream file("set1.txt");

			if (file.is_open())
			{
				while (getline(file, lines))
				{
					// cout<<line<<endl;
					arr1[a] = stoi(lines);
					cout << arr1[a] << endl;

					a++;

				}
				file.close();

			}
			int size = a;
			MySearch sort;
			cout << "\n Please enter a number to search:";
			cin >> SearchNum;




			//here array is unsorted 
			int Linear = sort.Linear_Search(arr1,0,a,SearchNum);
			if (Linear != -1)
			{
				cout << " The steps for linear unsorted search to the number " << SearchNum << " -- " << count1 << endl;
			}
			else
			{
				cout << " The entered number is not with in the array:: steps for the search is" << count1 << endl;
			}




			// here the array is sorted using selection sort method
			sort.Selection_Sort(arr1, a);
			printArray(arr1, a);



			// sorted linear search
			cout << " \n \n\n \n \n Please wait..... The array is still sorting" << endl;
			
			int Linearsorted = sort.Linear_Search(arr1,0,a,SearchNum);
			if (Linearsorted != -1)
			{
				cout << " \n The steps for linear sorted search to the number " << SearchNum << " -- " << count1 << endl;
			}
			else 
			{
				cout << " The entered number is not with in the array:: steps for the search is" << count1 << endl;
			}


			//sorted binary search
			int binary = sort.Binary_Search(arr1, 0, a, SearchNum);
			if (binary != -1)
			{
				cout << " \n The steps for binary sorted search to the number " << SearchNum << " -- " << count2 << endl;
			}
			else
			{
				cout << " The entered number is not with in the array:: steps for the search is" << count2 << endl;
			}



			//sorted jump search
			int jump = sort.Jump_Search(arr1, a, SearchNum);
			if (jump != -1)
			{
				cout << " \n The steps for jump sorted search to the number " << SearchNum << " -- " << count3 << endl;
			}
			else
			{
				cout << " The entered number is not with in the array:: steps for the search is" << count3 << endl;

			}

			//interpolation search
			int interpolation = sort.Interpolation_Sort(arr1, a, SearchNum);
			if (interpolation != -1)
			{
				cout << " \n The steps for interpolation sorted search to the number " << SearchNum << " -- " << count4 << endl;
			}
			else
			{
				cout << " The entered number is not with in the array:: steps for the search is" << count4 << endl;
			}
		
	
	
    system("pause");
	return 0;
}