#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <chrono>
#include <ctime>
#include <cstdlib>

// All the functions and algorithms are working correctly
// But count is not showing
int count3 = 0;
int count4 = 0;

using namespace std;

//this function is used to merge sorted sub arrays
void merge(string arr[], int l, int m, int r)	// l is for left index and r is right index of the sub-array of arr to be sorted
   
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;
    /* create two temporary arrays */
	string L[n1], R[n2];
	/* Copying data to temp arrays L[] and R[] */
	for (i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for (j = 0; j < n2; j++)
		R[j] = arr[m + 1 + j];

	/* Merge the temp arrays back into arr[l..r]*/
	i = 0; // Initial index of first subarray 
	j = 0; // Initial index of second subarray 
	k = l; // Initial index of merged subarray 
	while (i < n1 && j < n2)
	{
		if (L[i] <= R[j])
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
		k++;
		count4++;
	}

	//Copy the remaining elements of L[], if there are any
	while (i < n1)
	{
		arr[k] = L[i];
		i++;
		k++;
		count4++;
	}

	// Copy the remaining elements of R[], if there are any
	while (j < n2)
	{
		arr[k] = R[j];
		j++;
		k++;
		count4++;
	}
}

/* l is for left index and r is right index of the
   sub-array of arr to be sorted */


// function to print the array
void printArray(string arr[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << arr[i];
		cout << endl;
	}
}

void swap(string* a, string* b)
{
	string t = *a;
	*a = *b;
	*b = t;
}


int partition(string arr[], int low, int high) // this is done correctly
{
	string pivot = arr[high];// pivot
	int i = (low - 1); // index of smaller element
	
	
	for (int j = low; j <= high - 1; j++)
	{
		// if current element is smaller than or equal to pivot
		if (arr[j] <= pivot)
		{
			i++; //increment index of smaller element
			swap(&arr[i], &arr[j]);
		}count3++;

	}
	swap(&arr[i + 1], &arr[high]);
	count3++;

	return (i + 1);
	cout << " This is the steps in the quick sort algorithm: " << count3 << endl;
}



class MySortStrings
{
public:
	void SelectionSort(string *arr,int n);// this is done
	void InsertionSort(string *arr,int n);// this is done
	void BubbleSort(string *arr, int n);// this is done
	void MergeSort(string *arr,int l, int r);//this is done
	void QuickSort(string arr[], int left,int right);//this is done
};


void MySortStrings::SelectionSort(string * arr, int n ) // this is correct able to sort string
{
	int i,j,minindex;
	int count2 = 0;
	// one by one move boundary of unsorted array
	for ( i = 0; i < n - 1; i++)
	{
		//find the minimum element
		minindex = i;
		for (j = i + 1; j < n; j++)
		if (arr[j] < arr[minindex])
			minindex = j;
		count2++;
			
		//swap the found minimum elemnt with the first element
			swap(&arr[min_idx], &arr[i]);
		
    }
	cout << " Steps in selection sort:" <<count2<< endl;
}




void MySortStrings::BubbleSort(string *arr, int n)// this is corect able to sort string
{
	bool swapped;
	int count = 0;
	for (int i = 0; i < n - 1; i++)
	{
		swapped = false;
		for (int j = 0; j < n - i - 1; j++)
		{

			if (arr[j] > arr[j + 1])
			{
				string temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
				swapped = true;
			}
			count++;
		}
		if (swapped == false)
		{
			break;
		}
		count++;
    }
	cout << " Total counts of bubble sort:" << count << endl;
}



void  MySortStrings::InsertionSort(string *arr, int n)// this working correctly
{
	string key;
	int count1 = 0;
		int i, j;

	for (i = 0; i < n; i++)
	{
		key = arr[i];
		int j = i - 1;
		// move elemnts of arr that are gereter than the 
		// key to one position ,their current position

		while (j >= 0 && arr[j] > key)
		{
			arr[j + 1] = arr[j];
			j = j - 1;
			count1++;
        }
        arr[j + 1] = key;
    }
	cout << " Insertionsort:" << count1<<endl;
	cin.get();
	cin.get();
}

void MySortStrings::MergeSort(string *arr, int l, int r)//this function is working correctly
{
	if (l < r)
	{
		int m = l + (r - 1) / 2;
		MergeSort(arr, 1, m);
		MergeSort(arr, m + 1, r);
		merge(arr, l, m, r);
	}
}


void MySortStrings::QuickSort(string arr[], int left, int right)// this is done correctly
{
	if (left < right)
	{
		int pi = partition(arr, left, right);
		QuickSort(arr, left, pi - 1);
		QuickSort(arr, pi + 1, right);
    }
}












int main()
{
	int a = 0;
	string *arrr = NULL;
	arrr = new  string[10001];


	string lines;
	ifstream file("Words.txt");

	if (file.is_open())
	{
		while (getline(file, lines))
		{
			//cout<<line<<endl;
			arrr[a].append(lines);
			cout << arrr[a] << endl;
			a++;
			
		}
		file.close();

    }

	int size = a;

	cout << "\nEnter the sorting algorithm that you want to have:\n\n\n";
	cout << " Enter I for insertion sort\n Enter B for bubblesort \n Enter S for slection sort \n Enter M for merge sort\n";
	cout << " Enter Q for quick sort\n";
	char c;
	cin >> c;

	MySortStrings sort;

	switch (c)
	{
	case 'I':
	case 'i': {
		sort.InsertionSort(arrr, size);//working
		printArray(arrr, size);
		break;
	}
	case 'b':
	case 'B': {
		sort.BubbleSort(arrr, size);//working
		printArray(arrr, size);
		break; }
	case'S':
	case 's': {
		sort.SelectionSort(arrr,size);//working
		printArray(arrr, size);
		break;
	}
	case 'Q':
	case 'q': {
		sort.QuickSort(arr, 0, size - 1);
		printArray(arrr, size);
		cout << " Steps in quicksort:" << count3;
;
		break; }
	case 'M':
	case 'm': {
		sort.MergeSort(arrr, 0, size - 1);
		printArray(arrr, size);
		cout << " Steps in mergesort:" << count4;
		break;
	}
	default:
		cout << " Wrong input " << endl;
		break;
	}
	system("pause");
	system("pause");
	return 0;
}
